import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Serve } from '../../serve';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

@Component({
  selector: 'app-restpass',
  imports: [ReactiveFormsModule],
  templateUrl: './restpass.html',
  styleUrl: './restpass.scss',
})
export class Restpass {
otp: any;
  id: any;
  restForm: FormGroup;
  showOtp = false;

 constructor(private seve: Serve, private chd: ChangeDetectorRef, private rt: Router, private route: ActivatedRoute, private form: FormBuilder) {
    route.paramMap.subscribe((params: ParamMap) => {
      this.id = params.get('id');
    });
  }
  ngOnInit() {  
    this.restForm = this.form.group({
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{6,}$")]],
      confirmPassword:['', Validators.required],
      id: [this.id]
    });
  }
  

  resetPassword() {
   this.seve.resetPassword(this.restForm.value).then((data: any) => {
    console.log(this.restForm.value);
      if (data.message == 'Success') {
        alert('Password Reset Successfully');
        this.rt.navigate(['/guestmaster/login']);
      } 
      else if (data.message == 'not') {
        alert('Password and Confirm Password do not match');
      }
      else {
        alert('Password Reset Failed');
      }
    });
  }
}
