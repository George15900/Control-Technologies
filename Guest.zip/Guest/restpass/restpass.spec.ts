import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Restpass } from './restpass';

describe('Restpass', () => {
  let component: Restpass;
  let fixture: ComponentFixture<Restpass>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Restpass]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Restpass);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
