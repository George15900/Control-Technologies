import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-career',
  imports: [CommonModule,RouterLink],
  templateUrl: './career.html',
  styleUrl: './career.scss',
})
export class Career {
public jobary:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {
this.servies.jobvacancy_view().then((data:any)=>{
this.jobary=data;
this.cde.detectChanges();
});
}
getDaysAgo(postDate: any): number {
  const posted = new Date(postDate);
  const today = new Date();

  const diffTime = today.getTime() - posted.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 3600 * 24));

  return diffDays;
}
}
