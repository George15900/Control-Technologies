import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Route, Router, RouterLink } from '@angular/router';
import { Serve } from '../../serve';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-careersignup',
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './careersignup.html',
  styleUrl: './careersignup.scss',
})
export class Careersignup {
  savestatus = false;
  today = new Date().toISOString().split('T')[0];
  signupForm!: FormGroup;
  selectedFiles?: FileList;
  currentFile?: any;
  selectedFiles1?: FileList;
  currentFile1?: any;
  public user: any[] = [];
  FileInfo?: Observable<any>;
  message = '';
  constructor(private serve: Serve, private fb: FormBuilder, private router: Router,) { }
  ngOnInit(): void {
    this.signupForm = this.fb.group({
      name: ['', [Validators.required]],
      gmail: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")]],
      contact: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('[6-9][0-9]{9}')]],
      qualification: ['', [Validators.required]],
      username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(15), Validators.pattern('[a-zA-Z]{5,15}')]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{6,}$")]],
      photo: ['', [Validators.required]],
      id_card: ['', [Validators.required]],
      date: ['', [Validators.required]]
    })

  }

  selectFile(event: any) {
    this.selectedFiles = event.target.files;
  }
  selectFile1(event: any) {
    this.selectedFiles1 = event.target.files;
  }

  onSubmit() {
    this.savestatus = true;
    console.log(this.signupForm.value);
    if (this.selectedFiles && this.selectedFiles1) {
      const file: File | null = this.selectedFiles.item(0)
      const file1: File | null = this.selectedFiles1.item(0)

      if (file && file1) {
        this.currentFile = file;
        this.currentFile1 = file1;
        this.serve.upload(this.currentFile).subscribe(
          (event: any) => {
            this.message = event.body.message;
          });
        this.serve.upload(this.currentFile1).subscribe(
          (event: any) => {
            this.message = event.body.message;
          });
        this.signupForm.value.photo = this.currentFile.name;
        this.signupForm.value.id_card = this.currentFile1.name;
        console.log(this.signupForm.value);
        this.serve.careersignup(this.signupForm.value).then((data: any) => {
          // this.savestatus = false;
          if (data.message == "Success") {
            this.router.navigate(['guestmaster/login']);
            alert(' Registered Successfully');
          }
          else if (data.message == "exists") {
            alert(' Username already exists');
          }
          else {
            alert(' Registration Failed');
          }
        });
      }
    }
  }
}
