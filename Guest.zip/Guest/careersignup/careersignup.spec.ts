import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Careersignup } from './careersignup';

describe('Careersignup', () => {
  let component: Careersignup;
  let fixture: ComponentFixture<Careersignup>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Careersignup]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Careersignup);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
