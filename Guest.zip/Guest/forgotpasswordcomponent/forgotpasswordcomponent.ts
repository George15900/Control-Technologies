import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Serve } from '../../serve';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgotpasswordcomponent',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './forgotpasswordcomponent.html',
  styleUrl: './forgotpasswordcomponent.scss',
})
export class Forgotpasswordcomponent {
  otp: any;
  id: any;
  forgotForm: FormGroup;
  showOtp = false;

  constructor(private fb: FormBuilder,private serve:Serve,private router:Router) {
    this.forgotForm = this.fb.group({
      username: ['', Validators.required],
      otps: ['']
    });
  }

  sendOtp() {
    if (this.forgotForm.controls['username'].valid) {
       this.serve.forgot(this.forgotForm.value).then((data:any)=>{ 
      this.otp=data.otp;
      this.id=data.id;
       if(this.otp === "not"){
        alert("Invalid username");
      }
      else{
       this.showOtp = true;
      }
       });
    } else {
      this.forgotForm.controls['username'].markAsTouched();
    }
  }

  verifyOtp() {
    if (this.forgotForm.controls['otps'].value == this.otp) {
       this.router.navigate(['guestmaster/restpass/',this.id]);
    } else {
      alert("Invalid OTP");
    }
  }
}

