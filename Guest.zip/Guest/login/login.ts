import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Serve } from '../../serve';
import { Router, RouteReuseStrategy, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule,CommonModule,RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class Login {
  savestatus=false;
  public loginary:any[]=[];
  constructor(private fb: FormBuilder, private serve: Serve, private router:Router) {}
  loginForm!:FormGroup;
  
  ngOnInit(){
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }
 onSubmit() {
   // show validation messages
   this.savestatus = true;
   // mark all controls touched so errors appear immediately
   Object.values(this.loginForm.controls).forEach(control => control.markAsTouched());

   if (this.loginForm.invalid) {
     // prevent server call when form is invalid
     return;
   }

   this.serve.login(this.loginForm.value).then((data: any) => {
     this.loginary = data;
     if (data == "") {
       alert('Invalid username and password');
       this.router.navigate(['guestmaster/login']);
       return;
     }

     var role = this.loginary[0].role;
     localStorage.setItem('loginid', this.loginary[0].login_id);
     localStorage.setItem('uername ', this.loginary[0].Username);
     if (role == 'Admin') {
       this.router.navigate(['adminmaster/adminhome']);
     } else if (role == 'employee') {
       this.router.navigate(['emp-master/emphome']);
     } else if (role == 'jobseeker') {
       this.router.navigate(['job-master/job-home']);
     } else {
       alert('Invalid Username and password ');
     }
   });
}
}
