import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';

@Component({
  selector: 'app-message-view-staus',
  imports: [CommonModule],
  templateUrl: './message-view-staus.html',
  styleUrl: './message-view-staus.scss',
})
export class MessageViewStaus {
 public leave:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router,) { }  
ngOnInit(): void {
const loginid=localStorage.getItem('loginid');
this.servies.message_emp_view({id:loginid}).then((data:any)=>{
this.leave=data;
this.cde.detectChanges();
});
}
}
