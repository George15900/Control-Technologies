import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageViewStaus } from './message-view-staus';

describe('MessageViewStaus', () => {
  let component: MessageViewStaus;
  let fixture: ComponentFixture<MessageViewStaus>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MessageViewStaus]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MessageViewStaus);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
