import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Progressview } from './progressview';

describe('Progressview', () => {
  let component: Progressview;
  let fixture: ComponentFixture<Progressview>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Progressview]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Progressview);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
