import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-progressview',
  imports: [CommonModule],
  templateUrl: './progressview.html',
  styleUrl: './progressview.scss',
})
export class Progressview {
public progress:any[]=[];
constructor(private services:Serve, private roter:Router,private ch:ChangeDetectorRef){}
 ngOnInit(){
  const loginid=localStorage.getItem('loginid');
  this.services.progress_emp_view({emp_Id:loginid }).then((Data: any) => {
    this.progress = Data;
    this.ch.detectChanges();
  })
}
}
