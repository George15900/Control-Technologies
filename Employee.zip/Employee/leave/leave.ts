import { Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-leave',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './leave.html',
  styleUrl: './leave.scss',
})
export class Leave {
   today = new Date().toISOString().split('T')[0];
public work:any[]=[];
   leaveForm!:FormGroup;
constructor(private servies:Serve,  private router:Router, private formBuilder:FormBuilder) { }  
ngOnInit(): void {
this.leaveForm=this.formBuilder.group({
  description:['',Validators.required], 
  start:['',Validators.required],
  end:['',Validators.required],
  loginid: [localStorage.getItem('loginid')],
});
}
 Submit(){
  this.servies.leave_req(this.leaveForm.value).then((data: any) => {
    if (data.message == "Success") {
        alert(' Successfully Submited');
        window.location.reload();

      }
      else {
        alert('Submit Failed');
      }
  });
 }
}
