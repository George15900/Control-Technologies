import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-work-view',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './work-view.html',
  styleUrl: './work-view.scss',
})
export class WorkView {
  public work:any[]=[];
   workviewForm!:FormGroup;
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router, private formBuilder:FormBuilder) { }  
ngOnInit(): void {
const loginid=localStorage.getItem('loginid');
this.servies.work_emp_view({id:loginid}).then((data:any)=>{
this.work=data;
this.cde.detectChanges();
});
this.workviewForm=this.formBuilder.group({
  progress:['',Validators.required], 
  emp_id:['']
});
}
 Submit(workassign_id:any){
  this.workviewForm.patchValue({emp_id:workassign_id});
  // console.log(this.workviewForm.value);
  this.servies.progress(this.workviewForm.value).then((data: any) => {
    if (data.message == "Success") {
        alert(' Successfully Submited');
        this.router.navigate(['emp-master/work_view']);
      }
      else {
        alert('Submit Failed');
      }
  });
 }
}
