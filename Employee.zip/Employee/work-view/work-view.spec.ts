import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkView } from './work-view';

describe('WorkView', () => {
  let component: WorkView;
  let fixture: ComponentFixture<WorkView>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorkView]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
