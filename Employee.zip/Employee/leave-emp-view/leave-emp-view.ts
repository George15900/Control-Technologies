import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-leave-emp-view',
  imports: [CommonModule],
  templateUrl: './leave-emp-view.html',
  styleUrl: './leave-emp-view.scss',
})
export class LeaveEmpView {
 public leave:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router,) { }  
ngOnInit(): void {
const loginid=localStorage.getItem('loginid');
this.servies.leave_emp_view({id:loginid}).then((data:any)=>{
this.leave=data;
this.cde.detectChanges();
});
}
}
