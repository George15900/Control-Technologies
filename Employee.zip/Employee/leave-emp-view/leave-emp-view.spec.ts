import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveEmpView } from './leave-emp-view';

describe('LeaveEmpView', () => {
  let component: LeaveEmpView;
  let fixture: ComponentFixture<LeaveEmpView>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LeaveEmpView]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LeaveEmpView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
