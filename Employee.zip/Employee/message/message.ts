import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Serve } from '../../serve';
import { Router } from '@angular/router';

@Component({
  selector: 'app-message',
  imports: [ReactiveFormsModule],
  templateUrl: './message.html',
  styleUrl: './message.scss',
})
export class Message {

public work:any[]=[];
   messagefrom!:FormGroup;
constructor(private servies:Serve,  private router:Router, private formBuilder:FormBuilder) { }  
ngOnInit(): void {
this.messagefrom=this.formBuilder.group({
  Description:['',Validators.required] ,
  loginid: [localStorage.getItem('loginid')],
});
}
 Submit(){
  this.servies.message(this.messagefrom.value).then((data: any) => {
    if (data.message == "Success") {
        alert(' Successfully Submited');
         window.location.reload();

      }
      else {
        alert('Submit Failed');
      }
  });
 }
}
