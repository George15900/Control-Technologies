import { Component } from '@angular/core';

@Component({
  selector: 'app-emphome',
  imports: [],
  templateUrl: './emphome.html',
  styleUrl: './emphome.scss',
})
export class Emphome {

}
