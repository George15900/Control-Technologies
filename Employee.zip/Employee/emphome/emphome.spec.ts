import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Emphome } from './emphome';

describe('Emphome', () => {
  let component: Emphome;
  let fixture: ComponentFixture<Emphome>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Emphome]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Emphome);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
