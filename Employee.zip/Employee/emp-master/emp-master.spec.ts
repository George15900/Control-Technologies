import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpMaster } from './emp-master';

describe('EmpMaster', () => {
  let component: EmpMaster;
  let fixture: ComponentFixture<EmpMaster>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmpMaster]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpMaster);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
