import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-porfile',
  imports: [CommonModule,RouterLink],
  templateUrl: './porfile.html',
  styleUrl: './porfile.scss',
})
export class Porfile {
  public emparyy: any[] = [];
  constructor(private seve: Serve, private chd: ChangeDetectorRef, private rt: Router) {}
 
  ngOnInit() {
     const loginid=localStorage.getItem('loginid');
    this.seve.emp_viewdetails({ emp_Id:loginid }).then((res: any) => {
      console.log(res);
      this.emparyy = res;
      this.chd.detectChanges();
    });
  }
}
