import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-jobseeker-profile',
  imports: [CommonModule,RouterLink],
  templateUrl: './jobseeker-profile.html',
  styleUrl: './jobseeker-profile.scss',
})
export class JobseekerProfile {

      
    public jobary:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {
const loginid=localStorage.getItem('loginid');
this.servies.jobseeker_view({id:loginid}).then((data:any)=>{
this.jobary=data;
this.cde.detectChanges();

});
}  
  }
    

