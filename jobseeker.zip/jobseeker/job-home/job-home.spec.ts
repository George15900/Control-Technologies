import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobHome } from './job-home';

describe('JobHome', () => {
  let component: JobHome;
  let fixture: ComponentFixture<JobHome>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobHome]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobHome);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
