import { Component } from '@angular/core';

@Component({
  selector: 'app-job-home',
  imports: [],
  templateUrl: './job-home.html',
  styleUrl: './job-home.scss',
})
export class JobHome {

}
