import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-job-application',
  imports: [RouterLink,CommonModule],
  templateUrl: './job-application.html',
  styleUrl: './job-application.scss',
})
export class JobApplication {
  public jobary: any[] = [];
  constructor(
    private servies: Serve,
    private cde: ChangeDetectorRef,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.servies.jobvacancy_view().then((data: any) => {
      this.jobary = data;
      this.cde.detectChanges();
    });
  }

  trackByJob(index: number, item: any): any {
    // use a unique identifier for better ngFor performance
    return item.job_id || index;
  }
}
