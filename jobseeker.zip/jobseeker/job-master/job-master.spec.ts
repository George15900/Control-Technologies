import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobMaster } from './job-master';

describe('JobMaster', () => {
  let component: JobMaster;
  let fixture: ComponentFixture<JobMaster>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobMaster]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobMaster);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
