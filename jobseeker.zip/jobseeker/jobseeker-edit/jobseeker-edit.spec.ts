import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobseekerEdit } from './jobseeker-edit';

describe('JobseekerEdit', () => {
  let component: JobseekerEdit;
  let fixture: ComponentFixture<JobseekerEdit>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobseekerEdit]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobseekerEdit);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
