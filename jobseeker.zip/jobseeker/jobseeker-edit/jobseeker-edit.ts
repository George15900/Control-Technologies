import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-jobseeker-edit',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './jobseeker-edit.html',
  styleUrl: './jobseeker-edit.scss',
})
export class JobseekerEdit {
  public jobupdate!: FormGroup;
  public jobary: any[] = [];
  selectedFiles?: FileList;
  currentFile?: any;
  message = '';

  constructor(
    private servies: Serve,
    private cde: ChangeDetectorRef,
    private router: Router,
    private formBuilder: FormBuilder
  ) {}

  ngOnInit(): void {

    this.jobupdate = this.formBuilder.group({
      jobseeker_id:[''],
      jobseeker_name:[''],
      jobseeker_email:[''],
      jobseeker_contact:[''],
      jobseeker_qualific:[''],
      jobseeker_dob:[''],
      jobseeker_photo:['']
    });

    const loginid = localStorage.getItem('loginid');

    this.servies.jobseeker_view({ id: loginid }).then((data: any) => {

      this.jobary = data;
      this.cde.detectChanges();

      this.jobupdate.setValue({
        jobseeker_id: data[0].jobseeker_id,
        jobseeker_name: data[0].jobseeker_name,
        jobseeker_email: data[0].jobseeker_email,
        jobseeker_contact: data[0].jobseeker_contact,
        jobseeker_qualific: data[0].jobseeker_qualific,
        jobseeker_dob: data[0].jobseeker_dob,
        jobseeker_photo: data[0].jobseeker_photo
      });

    });
  }

  selectFile(event: any) {
    this.selectedFiles = event.target.files;
    this.imageupload();
  }

  imageupload() {

    if (this.selectedFiles) {

      const file = this.selectedFiles.item(0);

      if (file) {
        this.currentFile = file;

        this.servies.upload(file).subscribe((event: any) => {
          this.message = event.body.message;
        });

        // FIXED HERE
        this.jobupdate.patchValue({
          jobseeker_photo: file.name
        });
      }
    }
  }

  updateProfile() {

    this.servies.jobseeker_edit(this.jobupdate.value).then((data: any) => {

      if (data.message == "Success") {
        alert('Updated Successfully');
        this.router.navigate(['/jobseeker-home/jobseeker-profile']);
      } else {
        alert('Update Failed');
      }

    });
  }
}
