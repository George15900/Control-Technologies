import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobseekerApply } from './jobseeker-apply';

describe('JobseekerApply', () => {
  let component: JobseekerApply;
  let fixture: ComponentFixture<JobseekerApply>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobseekerApply]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JobseekerApply);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
