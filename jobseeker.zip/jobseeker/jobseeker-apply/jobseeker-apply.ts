import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap, Router, RouterLink } from '@angular/router';
import { Observable } from 'rxjs';
import { Comment } from '@angular/compiler';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-jobseeker-apply',
  imports: [CommonModule, ReactiveFormsModule,RouterLink],
  templateUrl: './jobseeker-apply.html',
  styleUrl: './jobseeker-apply.scss',
})
export class JobseekerApply {
  job_Id: any;
  appreq!: FormGroup;
  submitted = false;
  state_id: any;
  selectedFiles?: FileList;
  currentFile?: any;
  selectedFiles1?: FileList;
  currentFile1?: any;
  FileInfo?: Observable<any>;
  message = '';
  public jobary:any[]=[];
  constructor(private servies: Serve, private form: FormBuilder, private cde: ChangeDetectorRef, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.job_Id = params.get('job_Id');
    });
    this.appreq = this.form.group({
      experience:['', Validators.required],
      cv:['', Validators.required],
      loginid: [localStorage.getItem('loginid')],
      job_Id: [this.job_Id],
    });
console.log(localStorage.getItem('loginid'));
 this.servies.jobseeker_apply_view({id:localStorage.getItem('loginid'),jid:this.job_Id}).then((res:any)=>{
this.jobary=res;
this.cde.detectChanges();
});
  }
  selectFile1(event: any) {
    this.selectedFiles1 = event.target.files;
  }
  submit() {
    this.submitted = true;
    if (this.appreq.invalid) {
      this.appreq.markAllAsTouched();
      return;
    }
    console.log(this.appreq.value);
    if (this.selectedFiles1) {
      const file1: File | null = this.selectedFiles1.item(0)
      if ( file1) {
        this.currentFile1 = file1;
        this.servies.upload(this.currentFile1).subscribe(
          (event: any) => {
            this.message = event.body.message;
          });
        this.appreq.value.cv = this.currentFile1.name;
        this.servies.apply(this.appreq.value).then((data: any) => {
          if (data.message == "Success") {
            alert(' Registered Successfully');
          }
          else if (data.message == "applyed already") {
            alert('You have already applied for this job');
          }
          else {
            alert(' Registration Failed');
          }
        });
      }
    }
  }
}
