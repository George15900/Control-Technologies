import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';

@Component({
  selector: 'app-job-status',
  imports: [CommonModule],
  templateUrl: './job-status.html',
  styleUrl: './job-status.scss',
})
export class JobStatus {
  public jobary:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {
const loginid=localStorage.getItem('loginid');
this.servies.jobseeker_status({id:loginid}).then((data:any)=>{
this.jobary=data;
this.cde.detectChanges();
});
}

getStatusClass(status: string): string {
  if (!status) return 'pending';
  const statusLower = status.toLowerCase().trim();
  if (statusLower.includes('accepted') || statusLower.includes('approved')) return 'accepted';
  if (statusLower.includes('rejected') || statusLower.includes('decline')) return 'rejected';
  if (statusLower.includes('shortlist')) return 'shortlisted';
  return 'pending';
}

}
