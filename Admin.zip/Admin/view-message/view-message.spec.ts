import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMessage } from './view-message';

describe('ViewMessage', () => {
  let component: ViewMessage;
  let fixture: ComponentFixture<ViewMessage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewMessage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewMessage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
