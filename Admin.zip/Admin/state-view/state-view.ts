import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-state-view',
  imports: [],
  templateUrl: './state-view.html',
  styleUrl: './state-view.scss',
})
export class StateView {
  public stateary:any[]=[];
  public stateDelForm!:FormGroup
constructor(private servies:Serve, private form:FormBuilder, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {
this.servies.stateviews().then((data:any)=>{
this.stateary=data;
this.cde.detectChanges();

});
}
state_del(state_id:string){
  if (confirm('Are you sure you want to delete  district?')) {
this.servies.stateDel({state_id}).then((data:any)=>{
if(data.message=="Success"){
      alert('Delete Successfully');
    }
  else{
 alert('Delete Failed');
  }
});
}
}
}
