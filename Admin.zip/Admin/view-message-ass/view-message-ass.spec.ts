import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMessageAss } from './view-message-ass';

describe('ViewMessageAss', () => {
  let component: ViewMessageAss;
  let fixture: ComponentFixture<ViewMessageAss>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewMessageAss]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewMessageAss);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
