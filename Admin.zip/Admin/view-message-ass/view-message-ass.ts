import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-view-message-ass',
  imports: [CommonModule],
  templateUrl: './view-message-ass.html',
  styleUrl: './view-message-ass.scss',
})
export class ViewMessageAss {
public leave:any[]=[];
constructor(private servies: Serve, private cde: ChangeDetectorRef, private router: Router) { }

ngOnInit(): void {

  
    this.servies.message_view().then((stateData: any) => {

      // ✅ Check data is array
      if (Array.isArray(stateData)) {

        // ✅ Filter jobs requested to join
        this.leave = stateData.filter(item =>
          item.Status === 'Approved'
        );
        console.log("job",this.leave);

      } else {
        this.leave = [];
      }

      this.cde.detectChanges();
    })
    .catch((error) => {
      console.error('Error fetching leave:', error);
    });

  }
}
