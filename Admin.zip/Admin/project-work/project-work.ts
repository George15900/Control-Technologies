import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-project-work',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './project-work.html',
  styleUrl: './project-work.scss',
})
export class ProjectWork {
 public proarry: any[] = [];
 public workarry: any[] = [];
  project_id: any;
   savestatus=false;
  Workform!:FormGroup;
  constructor(private seve: Serve, private chd: ChangeDetectorRef, private rt: Router, private route: ActivatedRoute, private form:FormBuilder) {
    route.paramMap.subscribe((params: ParamMap) => {
      this.project_id = params.get('project_id');
    });
  }
  ngOnInit() {
    
    this.seve.project_work({ project_id: this.project_id }).then((res: any) => {
      console.log(res);
      this.proarry = res;
      this.chd.detectChanges();
    });
    this.seve.work_view({ project_id: this.project_id }).then((res: any) => {
      console.log(res);
      this.workarry = res;
      this.chd.detectChanges();
    });
     this.Workform = this.form.group({
      Name: ['',[Validators.required],Validators.pattern('[a-zA-Z ]*')],
      discription: ['',[Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      project_id: [''],
     });
  }
  Submit() {
    const formData = {
      ...this.Workform.value,
      project_id: this.project_id
    };
    this.seve.Work_add(formData).then((data: any) => {
      if (data.message == "Success") {
        alert(' Registered Successfully');
                  window.location.reload();
      }
      else {
        alert(' Registration Failed');
      }
    })
  }
  deletework(work_id:string){
   if (confirm('Are you sure you want to delete  work?')) {
  this.seve.work_del({work_id:work_id}).then((res:any)=>{
    if(res.message=="Success"){
      alert('Delete Successfully');
                window.location.reload();

    }
  else{
 alert('Delete Failed');
  }
  });
  }
}
}
