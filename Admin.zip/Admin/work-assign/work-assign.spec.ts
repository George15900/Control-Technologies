import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkAssign } from './work-assign';

describe('WorkAssign', () => {
  let component: WorkAssign;
  let fixture: ComponentFixture<WorkAssign>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorkAssign]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkAssign);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
