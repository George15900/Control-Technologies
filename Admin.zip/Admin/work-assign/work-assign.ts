import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-work-assign',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './work-assign.html',
  styleUrl: './work-assign.scss',
})
export class WorkAssign {
   today = new Date().toISOString().split('T')[0];
  public empary: any[] = [];
  public proary: any[] = [];
  public workarry: any[] = [];
  work_duiv_reg!: FormGroup;
  constructor(private servies: Serve, private cde: ChangeDetectorRef, private form: FormBuilder) { }
  ngOnInit(): void {
    this.work_duiv_reg = this.form.group({
      project_id: [''],
      work_id: [''],
      date: ['',Validators.required],
      emp_id: [''],
      date2: ['',Validators.required]
    });
    this.servies.emp_views().then((data: any) => {
      this.empary = data;
      this.cde.detectChanges();
    });
    this.servies.project_view().then((proData: any) => {
      this.proary = proData;
      this.cde.detectChanges();
    });
  }
  onchange() {
    const project_id = this.work_duiv_reg.value.project_id;
    this.servies.work_view({ project_id: project_id }).then((workData: any) => {
      this.workarry = workData;
      this.cde.detectChanges();
    });
  }
    Submit(employee_id:any) {
      this.work_duiv_reg.patchValue({ emp_id: employee_id });
    this.servies.work_assign(this.work_duiv_reg.value).then((data: any) => {
      if (data.message == "Success") {
        alert('Work Assigned Successfully');
      }
      else {
        alert('Work Assignment Failed');
      }
    })
  }
}
