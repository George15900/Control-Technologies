import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';

@Component({
  selector: 'app-req-leave-view',
  imports: [CommonModule],
  templateUrl: './req-leave-view.html',
  styleUrl: './req-leave-view.scss',
})
export class ReqLeaveView {
public leave:any[]=[];
constructor(private servies: Serve, private cde: ChangeDetectorRef, private router: Router) { }

ngOnInit(): void {

  
    this.servies.emp_leave_view().then((stateData: any) => {

      // ✅ Check data is array
      if (Array.isArray(stateData)) {

        // ✅ Filter jobs requested to join
        this.leave = stateData.filter(item =>
          item.leave_statues === 'Requested'
        );
        console.log("job",this.leave);

      } else {
        this.leave = [];
      }

      this.cde.detectChanges();
    })
    .catch((error) => {
      console.error('Error fetching leave:', error);
    });

  }

Update_leave_req(leave_request_id:number,status:string){
  let a=status;
   if (confirm('Are you'+status+'this leave ?')) {
  this.servies.Update_leave_req({leave_request_id:leave_request_id,status:status}).then((res:any)=>{
    if(res.message=="Success"){
      alert(a+'Successfully');
    }
  else{
 alert(a+'Failed');
  }
  });
  }
}
}
