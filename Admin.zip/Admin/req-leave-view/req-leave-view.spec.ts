import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReqLeaveView } from './req-leave-view';

describe('ReqLeaveView', () => {
  let component: ReqLeaveView;
  let fixture: ComponentFixture<ReqLeaveView>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReqLeaveView]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReqLeaveView);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
