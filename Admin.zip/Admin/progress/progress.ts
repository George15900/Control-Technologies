import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { from } from 'rxjs';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-progress',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './progress.html',
  styleUrl: './progress.scss',
})
export class Progress {
public progress:any[]=[];
public jobary:any[]=[];
jobform!:FormGroup;
constructor(private services:Serve, private roter:Router,private ch:ChangeDetectorRef,public form:FormBuilder){}
 ngOnInit(){
  this.jobform=this.form.group({
    project_id:['']
  });
  this.services.progress_view().then((Data: any) => {
    this.progress = Data;
    this.ch.detectChanges();
  })
  this.services.project_view().then((data:any)=>{
this.jobary=data;
this.ch.detectChanges();
});
}
  onchange(Event: any) {

    const project_id = this.jobform.value.project_id;
    this.services.progress_search({ project_id: project_id }).then((districtData: any) => {
      this.progress = districtData;
      this.ch.detectChanges();

    });
  }
}
