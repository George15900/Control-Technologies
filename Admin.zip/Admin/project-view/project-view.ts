import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-project-view',
  imports: [CommonModule,RouterLink],
  templateUrl: './project-view.html',
  styleUrl: './project-view.scss',
})
export class ProjectView {
public proary:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {
this.servies.project_view().then((data:any)=>{
this.proary=data;
this.cde.detectChanges();
});
}
deletepro(project_id:string){
   if (confirm('Are you sure you want to delete  Project?')) {
  this.servies.project_del({job_id:project_id}).then((res:any)=>{
    if(res.message=="Success"){
      alert('Delete Successfully');
                window.location.reload();
    }
  else{
 alert('Delete Failed');
  }
  });
  }
}
Complete(project_id:string){
   if (confirm('Are you sure you want to Complete  Project?')) {
  this.servies.project_complete({job_id:project_id}).then((res:any)=>{
    if(res.message=="Success"){
      alert('Project Completed Successfully');
    window.location.reload();
    }
  else{
 alert('Project Completion Failed');
  }
});
  }
}
}