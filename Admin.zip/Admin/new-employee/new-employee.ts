import { ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Serve } from '../../serve';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { compileNgModule } from '@angular/compiler';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-new-employee',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './new-employee.html',
  styleUrl: './new-employee.scss',
})
export class NewEmployee {
  savestatus=false;
  today = new Date().toISOString().split('T')[0];
  public stateary: any[] = [];
  public districtary: any[] = [];
  public designationarry: any[] = [];
  empreg!: FormGroup;
  state_id: any;
  selectedFiles?: FileList;
  currentFile?: any;
  selectedFiles1?: FileList;
  currentFile1?: any;
  FileInfo?: Observable<any>;
  message = '';
  public emparyy: any[] = [];
  jobseeker_id : any;
  constructor(private servies: Serve, private form: FormBuilder, private cde: ChangeDetectorRef, private router: Router,private route: ActivatedRoute) { 
   route.paramMap.subscribe((params: ParamMap) => {
      this.jobseeker_id  = params.get('jobseeker_id');
    });
  }
  ngOnInit(): void {
     this.empreg = this.form.group({
      per_address: ['',Validators.required,Validators.pattern('^[a-zA-Z ]*$')],
      pincode: ['',[Validators.required, Validators.pattern('^[0-9]{6}$')]],
      state_id: ['',Validators.required,Validators.pattern('^[0-9]+$')],
      district_id: ['',Validators.required],
      current_address: ['',Validators.required,Validators.pattern('^[a-zA-Z ]*$')],
      crr_pincode: ['',Validators.required,Validators.pattern('^[0-9]{6}$')],
      gender: ['',Validators.required],
      exprenes: ['',Validators.required,Validators.pattern('^[0-9]+$')],
      designation_id: ['',Validators.required],
      dob: ['',Validators.required],
      total_leave:['',Validators.required],
      Username: ['',[Validators.required, Validators.minLength(5), Validators.maxLength(15), Validators.pattern('[a-zA-Z]{5,15}')]],
      Password:['', [Validators.required, Validators.minLength(6), Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&]).{6,}$")]],
      jobseeker_id:[this.jobseeker_id ]
    });
    this.servies.stateviews().then((stateData: any) => {
      this.stateary = stateData;
    });
    this.servies.designations_view().then((Data: any) => {
      this.designationarry = Data;
    });
    this.cde.detectChanges();
  }
  onchange() {
    const state_id = this.empreg.value.state_id;
    this.servies.distrite_view({ state_id: state_id }).then((districtData: any) => {
      this.districtary = districtData;
    });
  }
  onSubmit() {
    this.servies.new_empinsert(this.empreg.value).then((result: any) => {
      this.savestatus=true;
      if (result.message == "Success") {
            alert(' Registered Successfully');
                    window.location.reload();
          }
           else if (result.message == "exists") {
            alert(' Username already exists');
          }
          else {
            alert(' Registration Failed');
          }
    });
    }
}
