import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkAssignview } from './work-assignview';

describe('WorkAssignview', () => {
  let component: WorkAssignview;
  let fixture: ComponentFixture<WorkAssignview>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorkAssignview]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkAssignview);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
