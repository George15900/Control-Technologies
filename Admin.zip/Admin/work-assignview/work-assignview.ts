import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-work-assignview',
  imports: [CommonModule],
  templateUrl: './work-assignview.html',
  styleUrl: './work-assignview.scss',
})
export class WorkAssignview {
  public work:any[]=[];
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router) { }  
ngOnInit(): void {

this.servies.work_assign_view().then((data:any)=>{
this.work=data;
this.cde.detectChanges();
});
}
deleteworkassign(workassign_id:string){
   if (confirm('Are you sure you want to delete this Record?')) {
  this.servies.deleteworkassign({workassign_id:workassign_id}).then((res:any)=>{
    if(res.message=="Success"){
      alert('Delete Successfully');
    }
  else{
 alert('Delete Failed');
  }
  });
  }
}

}
