import { ChangeDetectorRef, Component } from '@angular/core';
import { Serve } from '../../serve';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-leave-view',
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './leave-view.html',
  styleUrl: './leave-view.scss',
})
export class LeaveView {
public leaveary:any[]=[];
leaveform!:FormGroup;
constructor(private servies:Serve, private cde:ChangeDetectorRef, private router:Router,private formBuilder:FormBuilder) { }  
ngOnInit(): void {
this.leaveform = this.formBuilder.group({
  noofleave: [''],
  // Year: ['']
});
this.servies.leave_view().then((data:any)=>{
this.leaveary=data;
this.cde.detectChanges();
});
}
deleteleave(leave_id:string){
   if (confirm('Are you sure you want to delete  Leave Record?')) {
  this.servies.leave_del({leave_id:leave_id}).then((res:any)=>{
    if(res.message=="Success"){
      alert('Delete Successfully');
    }
  else{
 alert('Delete Failed');
  }
  });
  }
}
updateLeave(){
   this.servies.leaveform(this.leaveform.value).then((data: any) => {
      if (data.message === "Success") {
        alert(' Updated Successfully');
      }
      else {
        alert(' Update Failed');
      }
    })
}
}
