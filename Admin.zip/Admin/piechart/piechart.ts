import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  ViewChild,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';

import Chart from 'chart.js/auto';

import { Serve } from '../../serve';

@Component({
  selector: 'app-piechart',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './piechart.html',
  styleUrl: './piechart.scss',
})
export class Piechart implements AfterViewInit, OnInit {

  categorydataarray: any[] = [];
  projectList: any[] = [];
  reportdetails: any[] = [];
  Registrationdata: any[] = [];

  reportformgroup!: FormGroup;

  pieChart!: Chart;
  barChart!: Chart;

   title = 'Excel'; 

  @ViewChild('myChart') myChart!: ElementRef;
  @ViewChild('myChart1') myChart1!: ElementRef;
  @ViewChild('TABLE', { static: false }) TABLE!: ElementRef;

  constructor(
    private fb: FormBuilder,
    private db: Serve,
    private chg: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.reportformgroup = this.fb.group({
      startdate: [''],
      enddate: ['']
    });

    this.productviewdata();
  }

  ngAfterViewInit(): void {

    this.db.piechart().then((data: any) => {
      this.categorydataarray = data;
      this.createPieChart();
      this.chg.detectChanges();
    });

    this.db.barchart().then((response: any) => {
      this.projectList = response;
      this.renderBarChart();
      this.chg.detectChanges();
    });
  }

  // ---------------- PIE CHART ----------------

  createPieChart() {

    const chartData = {
      labels: this.categorydataarray.map(item => item.project_name),
      datasets: [{
        data: this.categorydataarray.map(item => item.project_id),
        backgroundColor: [
          'rgba(38,213,129,0.7)',
          'rgba(54,162,235,0.7)',
          'rgba(255,206,86,0.7)',
          'rgba(255,99,132,0.7)'
        ]
      }]
    };

    this.pieChart = new Chart(this.myChart.nativeElement, {
      type: 'pie',
      data: chartData,
      options: {
        responsive: true
      }
    });
  }

  // ---------------- BAR CHART ----------------

  renderBarChart() {

    const projectNames = this.projectList.map(p => p.project_name);
    const projectCounts = this.projectList.map(p => p.count);

    this.barChart = new Chart(this.myChart1.nativeElement, {
      type: 'bar',
      data: {
        labels: projectNames,
        datasets: [{
          label: 'Work Assign Count',
          data: projectCounts,
          backgroundColor: [
            'rgba(38,213,129,0.7)',
            'rgba(54,162,235,0.7)',
            'rgba(255,206,86,0.7)',
            'rgba(255,99,132,0.7)'
          ]
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Project Count'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Project Name'
            }
          }
        }
      }
    });
  }

  // ---------------- REPORT ----------------



  // ---------------- PRODUCT VIEW ----------------

  productviewdata() {
    this.db.reportexcel(this.reportformgroup.value).then((data: any) => {
      this.Registrationdata = data;
    });
  }

  // ---------------- EXCEL EXPORT ----------------



}
